class PresentationController {
    constructor() {
        this.currentSlide = 1;
        this.totalSlides = 13;
        this.slides = document.querySelectorAll('.slide');
        this.thumbnails = document.querySelectorAll('.thumbnail');
        this.progressFill = document.querySelector('.progress-fill');
        this.currentSlideSpan = document.querySelector('.current-slide');
        this.totalSlidesSpan = document.querySelector('.total-slides');
        this.prevBtn = document.getElementById('prevBtn');
        this.nextBtn = document.getElementById('nextBtn');
        
        this.init();
    }
    
    init() {
        // Set initial state
        this.updateSlideDisplay();
        this.updateProgressBar();
        this.updateSlideCounter();
        this.updateNavigationButtons();
        
        // Event listeners
        this.setupEventListeners();
        
        // Auto-advance timer (optional - can be enabled)
        this.autoAdvanceTimer = null;
        this.autoAdvanceDelay = 10000; // 10 seconds
        
        console.log('QuantumScholae.ai Presentation initialized');
    }
    
    setupEventListeners() {
        // Navigation buttons - Fixed event binding
        if (this.prevBtn) {
            this.prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.previousSlide();
            });
        }
        
        if (this.nextBtn) {
            this.nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentSlide === this.totalSlides) {
                    this.goToSlide(1); // Restart functionality
                } else {
                    this.nextSlide();
                }
            });
        }
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyNavigation(e));
        
        // Thumbnail navigation - Fixed event binding
        this.thumbnails.forEach((thumbnail, index) => {
            thumbnail.addEventListener('click', (e) => {
                e.preventDefault();
                this.goToSlide(index + 1);
            });
        });
        
        // Touch/swipe support for mobile
        this.setupTouchNavigation();
        
        // Prevent accidental page navigation
        window.addEventListener('beforeunload', (e) => {
            if (this.currentSlide > 1) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    }
    
    setupTouchNavigation() {
        let startX = null;
        let startY = null;
        const minSwipeDistance = 50;
        
        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        });
        
        document.addEventListener('touchend', (e) => {
            if (!startX || !startY) return;
            
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const deltaX = startX - endX;
            const deltaY = startY - endY;
            
            // Check if it's a horizontal swipe (not vertical scroll)
            if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > minSwipeDistance) {
                if (deltaX > 0) {
                    // Swipe left - next slide
                    this.nextSlide();
                } else {
                    // Swipe right - previous slide
                    this.previousSlide();
                }
            }
            
            startX = null;
            startY = null;
        });
    }
    
    handleKeyNavigation(e) {
        switch(e.key) {
            case 'ArrowRight':
            case ' ': // Spacebar
                e.preventDefault();
                this.nextSlide();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.previousSlide();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSlide(1);
                break;
            case 'End':
                e.preventDefault();
                this.goToSlide(this.totalSlides);
                break;
            case 'Escape':
                e.preventDefault();
                this.toggleFullscreen();
                break;
        }
    }
    
    nextSlide() {
        if (this.currentSlide < this.totalSlides) {
            this.goToSlide(this.currentSlide + 1);
        }
        this.resetAutoAdvance();
    }
    
    previousSlide() {
        if (this.currentSlide > 1) {
            this.goToSlide(this.currentSlide - 1);
        }
        this.resetAutoAdvance();
    }
    
    goToSlide(slideNumber) {
        if (slideNumber < 1 || slideNumber > this.totalSlides || slideNumber === this.currentSlide) {
            return;
        }
        
        const previousSlide = this.currentSlide;
        this.currentSlide = slideNumber;
        
        // Update slide visibility with animation
        this.animateSlideTransition(previousSlide, slideNumber);
        
        // Update UI elements
        this.updateSlideDisplay();
        this.updateProgressBar();
        this.updateSlideCounter();
        this.updateNavigationButtons();
        this.updateThumbnails();
        
        // Analytics/tracking (placeholder)
        this.trackSlideChange(slideNumber);
    }
    
    animateSlideTransition(fromSlide, toSlide) {
        const fromSlideElement = document.querySelector(`[data-slide="${fromSlide}"]`);
        const toSlideElement = document.querySelector(`[data-slide="${toSlide}"]`);
        
        if (!fromSlideElement || !toSlideElement) return;
        
        // Remove active class from previous slide
        fromSlideElement.classList.remove('active');
        
        // Add transition classes based on direction
        if (toSlide > fromSlide) {
            // Going forward
            fromSlideElement.classList.add('prev');
            toSlideElement.style.transform = 'translateX(100px)';
        } else {
            // Going backward
            fromSlideElement.style.transform = 'translateX(-100px)';
        }
        
        // Add active class to new slide after a brief delay
        setTimeout(() => {
            toSlideElement.classList.add('active');
            toSlideElement.style.transform = '';
            
            // Clean up transition classes
            setTimeout(() => {
                fromSlideElement.classList.remove('prev');
                fromSlideElement.style.transform = '';
            }, 600);
        }, 50);
    }
    
    updateSlideDisplay() {
        this.slides.forEach((slide, index) => {
            const slideNumber = index + 1;
            if (slideNumber === this.currentSlide) {
                slide.classList.add('active');
            } else {
                slide.classList.remove('active');
            }
        });
    }
    
    updateProgressBar() {
        const progress = (this.currentSlide / this.totalSlides) * 100;
        if (this.progressFill) {
            this.progressFill.style.width = `${progress}%`;
        }
    }
    
    updateSlideCounter() {
        if (this.currentSlideSpan) {
            this.currentSlideSpan.textContent = this.currentSlide;
        }
        if (this.totalSlidesSpan) {
            this.totalSlidesSpan.textContent = this.totalSlides;
        }
    }
    
    updateNavigationButtons() {
        if (this.prevBtn) {
            this.prevBtn.disabled = this.currentSlide === 1;
        }
        
        if (this.nextBtn) {
            // Update button text and functionality for last slide
            if (this.currentSlide === this.totalSlides) {
                this.nextBtn.textContent = 'Restart';
                this.nextBtn.disabled = false;
            } else {
                this.nextBtn.textContent = 'Next';
                this.nextBtn.disabled = false;
            }
        }
    }
    
    updateThumbnails() {
        this.thumbnails.forEach((thumbnail, index) => {
            const slideNumber = index + 1;
            if (slideNumber === this.currentSlide) {
                thumbnail.classList.add('active');
            } else {
                thumbnail.classList.remove('active');
            }
        });
    }
    
    // Auto-advance functionality (optional)
    startAutoAdvance() {
        this.autoAdvanceTimer = setInterval(() => {
            if (this.currentSlide < this.totalSlides) {
                this.nextSlide();
            } else {
                this.stopAutoAdvance();
            }
        }, this.autoAdvanceDelay);
    }
    
    stopAutoAdvance() {
        if (this.autoAdvanceTimer) {
            clearInterval(this.autoAdvanceTimer);
            this.autoAdvanceTimer = null;
        }
    }
    
    resetAutoAdvance() {
        this.stopAutoAdvance();
        // Uncomment to enable auto-advance
        // this.startAutoAdvance();
    }
    
    // Fullscreen functionality
    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log(`Error attempting to enable fullscreen: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    }
    
    // Slide overview/thumbnail view (future enhancement)
    showSlideOverview() {
        // Implementation for slide overview mode
        console.log('Slide overview mode - feature coming soon');
    }
    
    // Analytics/tracking
    trackSlideChange(slideNumber) {
        // Placeholder for analytics tracking
        console.log(`Slide changed to: ${slideNumber}`);
        
        // Example: Send to analytics service
        // gtag('event', 'slide_view', {
        //     slide_number: slideNumber,
        //     presentation_id: 'quantumscholae-ai'
        // });
    }
    
    // Export functionality
    exportPresentation() {
        window.print();
    }
    
    // Presentation control methods for external use
    getCurrentSlide() {
        return this.currentSlide;
    }
    
    getTotalSlides() {
        return this.totalSlides;
    }
    
    getSlideProgress() {
        return (this.currentSlide / this.totalSlides) * 100;
    }
}

// Additional utility functions
class PresentationUtils {
    static formatNumber(num) {
        if (num >= 1000000000) {
            return (num / 1000000000).toFixed(1) + 'B';
        } else if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }
    
    static animateCountUp(element, finalValue, duration = 2000) {
        const startValue = 0;
        const startTime = performance.now();
        
        function updateCount(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const currentValue = Math.floor(startValue + (finalValue - startValue) * easeOut);
            
            element.textContent = PresentationUtils.formatNumber(currentValue);
            
            if (progress < 1) {
                requestAnimationFrame(updateCount);
            } else {
                element.textContent = PresentationUtils.formatNumber(finalValue);
            }
        }
        
        requestAnimationFrame(updateCount);
    }
    
    static highlightText(text, className = 'highlight') {
        return `<span class="${className}">${text}</span>`;
    }
}

// Intersection Observer for slide animations
class SlideAnimationController {
    constructor() {
        this.setupIntersectionObserver();
    }
    
    setupIntersectionObserver() {
        const options = {
            threshold: 0.5,
            rootMargin: '0px'
        };
        
        this.observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateSlideContent(entry.target);
                }
            });
        }, options);
        
        // Observe all slides
        document.querySelectorAll('.slide').forEach(slide => {
            this.observer.observe(slide);
        });
    }
    
    animateSlideContent(slide) {
        // Animate stats and numbers when slide becomes visible
        const statNumbers = slide.querySelectorAll('.stat-number, .stat-value, .projection-value, .metric-value');
        statNumbers.forEach(element => {
            const text = element.textContent;
            const numericValue = parseFloat(text.replace(/[^0-9.]/g, ''));
            if (!isNaN(numericValue) && !element.dataset.animated) {
                element.dataset.animated = 'true';
                PresentationUtils.animateCountUp(element, numericValue);
            }
        });
        
        // Animate feature cards
        const features = slide.querySelectorAll('.feature, .competitor, .revenue-stream');
        features.forEach((feature, index) => {
            setTimeout(() => {
                feature.style.opacity = '0';
                feature.style.transform = 'translateY(20px)';
                feature.style.transition = 'all 0.6s ease';
                
                setTimeout(() => {
                    feature.style.opacity = '1';
                    feature.style.transform = 'translateY(0)';
                }, 100);
            }, index * 150);
        });
    }
}

// Keyboard shortcuts help
class KeyboardShortcutsHelp {
    constructor() {
        this.helpVisible = false;
        this.createHelpOverlay();
        this.setupHelpToggle();
    }
    
    createHelpOverlay() {
        const helpOverlay = document.createElement('div');
        helpOverlay.id = 'keyboard-help';
        helpOverlay.className = 'keyboard-help-overlay hidden';
        helpOverlay.innerHTML = `
            <div class="help-content">
                <h3>Keyboard Shortcuts</h3>
                <div class="shortcuts-grid">
                    <div class="shortcut">
                        <kbd>→</kbd> <span>Next slide</span>
                    </div>
                    <div class="shortcut">
                        <kbd>←</kbd> <span>Previous slide</span>
                    </div>
                    <div class="shortcut">
                        <kbd>Space</kbd> <span>Next slide</span>
                    </div>
                    <div class="shortcut">
                        <kbd>Home</kbd> <span>First slide</span>
                    </div>
                    <div class="shortcut">
                        <kbd>End</kbd> <span>Last slide</span>
                    </div>
                    <div class="shortcut">
                        <kbd>Esc</kbd> <span>Toggle fullscreen</span>
                    </div>
                    <div class="shortcut">
                        <kbd>?</kbd> <span>Show/hide help</span>
                    </div>
                </div>
                <button class="close-help">Close</button>
            </div>
        `;
        document.body.appendChild(helpOverlay);
        
        // Add CSS for help overlay
        const style = document.createElement('style');
        style.textContent = `
            .keyboard-help-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                backdrop-filter: blur(5px);
            }
            
            .keyboard-help-overlay.hidden {
                display: none;
            }
            
            .help-content {
                background: var(--color-surface);
                padding: var(--space-32);
                border-radius: var(--radius-lg);
                max-width: 500px;
                width: 90%;
            }
            
            .help-content h3 {
                color: var(--color-text);
                margin-bottom: var(--space-20);
                text-align: center;
            }
            
            .shortcuts-grid {
                display: grid;
                gap: var(--space-12);
                margin-bottom: var(--space-20);
            }
            
            .shortcut {
                display: flex;
                align-items: center;
                gap: var(--space-12);
            }
            
            .shortcut kbd {
                background: var(--color-secondary);
                padding: var(--space-4) var(--space-8);
                border-radius: var(--radius-sm);
                font-family: var(--font-family-mono);
                font-size: var(--font-size-sm);
                min-width: 40px;
                text-align: center;
            }
            
            .shortcut span {
                color: var(--color-text-secondary);
            }
            
            .close-help {
                width: 100%;
                padding: var(--space-8) var(--space-16);
                background: var(--color-primary);
                color: var(--color-white);
                border: none;
                border-radius: var(--radius-base);
                cursor: pointer;
                transition: background 0.3s ease;
            }
            
            .close-help:hover {
                background: var(--color-primary-hover);
            }
        `;
        document.head.appendChild(style);
    }
    
    setupHelpToggle() {
        document.addEventListener('keydown', (e) => {
            if (e.key === '?' || (e.key === '/' && e.shiftKey)) {
                e.preventDefault();
                this.toggleHelp();
            }
        });
        
        // Use setTimeout to ensure elements are created
        setTimeout(() => {
            const closeBtn = document.querySelector('.close-help');
            const overlay = document.getElementById('keyboard-help');
            
            if (closeBtn) {
                closeBtn.addEventListener('click', () => this.hideHelp());
            }
            if (overlay) {
                overlay.addEventListener('click', (e) => {
                    if (e.target === overlay) this.hideHelp();
                });
            }
        }, 100);
    }
    
    toggleHelp() {
        if (this.helpVisible) {
            this.hideHelp();
        } else {
            this.showHelp();
        }
    }
    
    showHelp() {
        const helpElement = document.getElementById('keyboard-help');
        if (helpElement) {
            helpElement.classList.remove('hidden');
            this.helpVisible = true;
        }
    }
    
    hideHelp() {
        const helpElement = document.getElementById('keyboard-help');
        if (helpElement) {
            helpElement.classList.add('hidden');
            this.helpVisible = false;
        }
    }
}

// Initialize the presentation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add a small delay to ensure all elements are properly loaded
    setTimeout(() => {
        // Initialize main presentation controller
        window.presentationController = new PresentationController();
        
        // Initialize slide animations
        window.slideAnimationController = new SlideAnimationController();
        
        // Initialize keyboard shortcuts help
        window.keyboardHelp = new KeyboardShortcutsHelp();
        
        console.log('QuantumScholae.ai Presentation fully initialized');
    }, 100);
    
    // Add global event listeners for presentation control
    window.addEventListener('resize', () => {
        // Handle responsive adjustments
        console.log('Window resized, adjusting presentation layout');
    });
    
    // Add focus management for accessibility
    document.addEventListener('focusin', (e) => {
        if (e.target.classList.contains('slide')) {
            // Ensure focused slide is visible
            const slideNumber = parseInt(e.target.dataset.slide);
            if (slideNumber && window.presentationController && slideNumber !== window.presentationController.getCurrentSlide()) {
                window.presentationController.goToSlide(slideNumber);
            }
        }
    });
});

// Export for external use
window.QuantumScholaePresentation = {
    controller: null,
    
    init() {
        if (!this.controller) {
            this.controller = new PresentationController();
        }
        return this.controller;
    },
    
    goToSlide(slideNumber) {
        if (this.controller) {
            this.controller.goToSlide(slideNumber);
        }
    },
    
    nextSlide() {
        if (this.controller) {
            this.controller.nextSlide();
        }
    },
    
    previousSlide() {
        if (this.controller) {
            this.controller.previousSlide();
        }
    },
    
    getCurrentSlide() {
        return this.controller ? this.controller.getCurrentSlide() : 1;
    },
    
    startAutoAdvance() {
        if (this.controller) {
            this.controller.startAutoAdvance();
        }
    },
    
    stopAutoAdvance() {
        if (this.controller) {
            this.controller.stopAutoAdvance();
        }
    },
    
    exportPresentation() {
        if (this.controller) {
            this.controller.exportPresentation();
        }
    }
};